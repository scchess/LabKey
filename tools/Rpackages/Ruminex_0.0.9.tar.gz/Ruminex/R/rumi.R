# Youyi: using install.packages() may only get version 1.5.2 of drc, the latest is 1.9.3 on 7/18/2010
library(drc) 

# self start functions
ssfct.drc.1.5.2 <- function (dataFra) {
    x <- dataFra[, 1]
    y <- dataFra[, 2]
    startVal <- rep(0, 5)
    startVal[3] <- max(y) + 0.001
    startVal[2] <- min(y) - 0.001
    startVal[5] <- 1
    indexT2 <- (x > 0)
    x2 <- x[indexT2]
    y2 <- y[indexT2]
    startVal[c(1, 4)] <- find.be2(x2, y2, startVal[2] - 0.001, 
        startVal[3])
#    print (startVal)
    return(startVal)
}
find.be2 <- function(x, y, c, d)
{
#    myprint (x," ")
#    myprint (y)
#    myprint (c)
#    myprint (d)
    logitTrans <- log((d - y)/(y - c))  
    
    lmFit <- lm(logitTrans ~ log(x))
#        eVal <- exp((-coef(logitFit)[1]/coef(logitFit)[2]))
#        bVal <- coef(logitFit)[2]
    
    coefVec <- coef(lmFit)
    bVal <- coefVec[2]        
    eVal <- exp(-coefVec[1]/bVal)    
    
    return(as.vector(c(bVal, eVal)))
}
ss.fct.via.LL4= function (dataFra) {
    x <- dataFra[, 1]
    y <- dataFra[, 2]
    fit0= drm(y ~ x, fct = LL.4(), weights= y^-.5)
    start=c(coef(fit0), 1)
    return (start)
}

# sometimes when y is MFI, the lower asymptote can be below 0, after taking log, we get NaN
gof.cost=function (x) {
    x=ifelse (is.na(x), 10, x)
    mean(abs(x))
} 

# Args:
#   fit is a drc fit object
#   logMFI is a vector of log MFI, which will be averaged, or a single value
# Returs:
#   est, se., ...
#   range of expected.conc if out of range in any way
# Issues
#   We make the assumption that the first two columns of fit$data are conc and MFI, where fit is returned by drm
#   not vectorized
getConc=function(fit, logMFI, verbose=FALSE, check.out.of.range=TRUE, fit.4pl=FALSE) {

    m=length(logMFI) #
    y=mean(logMFI)

    # fill-in value when out of bound
    x.inf = log(max(fit$data[,1]))
    x.ninf = log(min(fit$data[,1]))
    se1 = Inf

    b=coef(fit)[1]; c=coef(fit)[2]; d=coef(fit)[3]; e=coef(fit)[4];
    if(fit.4pl==FALSE) f=coef(fit)[5] ###CHANGE 1 6/16/2011

    if(fit.4pl==FALSE) x = FivePL.x.inv(y, coef(fit)) ###CHANGE 7 6/16/2011
    if(fit.4pl==TRUE) x = FourPL.x.inv(y, coef(fit)) ###CHANGE 8 6/16/2011

    if(check.out.of.range) {
        # if MFI outside standards MFI, set of Inf
        if ( y < min(fit$data[,2]) ) return (c("log.conc"=x.ninf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
        else if ( y > max(fit$data[,2]) ) return (c("log.conc"=x.inf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
        if (verbose) print("pass test 1")

        # if estimated conc outside expected conc, set to Inf
        if ( x < min(fit$data[,1]) ) return (c("log.conc"=x.ninf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
        else if ( x > max(fit$data[,1]) ) return (c("log.conc"=x.inf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
        if (verbose) print("pass test 3")
    }

    # if estimated conc outside asymptote, set to Inf
    if ( y < c ) return (c("log.conc"=x.ninf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
    else if ( y > d ) return (c("log.conc"=x.inf, "s.e."=se1, "concentration"=NaN, "lower.bound"=NaN, "upper.bound"=NaN, "s1"=NaN, "s2"=NaN, "se.x"=NaN))
    if (verbose) print("pass test 2")


    if(fit.4pl==FALSE){ ###CHANGE 2 6/16/2011
    A=((d-c)/(y-c))^(1/f)-1
    B=(d-c)/(y-c)

    dx.db = -log(A)*A^(1/b)*b^(-2)*e
    dx.dc = e/b*A^(1/b-1)*B^(1/f-1) *(1/f)*(d-y)/(y-c)^2
    dx.dd = e/b*A^(1/b-1)*B^(1/f-1) *(1/f)/(y-c)
    dx.de = A^(1/b)
    dx.df = e/b*A^(1/b-1)*B^(1/f) *log(B)*(-1/f^2)
    D.beta= c(dx.db, dx.dc, dx.dd, dx.de, dx.df)
    V.beta = vcov(fit)

    dx.dy = -e/(b*f)*A^{1/b-1}*B^{1/f+1}/(d-c)
    sigma2 = summary(fit)$resVar
    }
    
    if(fit.4pl==TRUE){ ###CHANGE 3 6/16/2011, added A/B wording to mirror 5pl
    A=((d-c)/(y-c))-1

    dx.db = -(e/b^2)*log(A)*(A)^(1/b) #dx/db
    dx.dc = (e/b)*((d-y)/(y-c)^2)*(A)^(1/b-1) #dx/dc
    dx.dd = (e/b)*(1/(y-c))*(A)^(1/b-1) #dx/dd
    dx.de = (A)^(1/b) #dx/de
    D.beta= c(dx.db, dx.dc, dx.dd, dx.de)
    V.beta = vcov(fit)

    dx.dy = -(e/b)*((d-c)/(y-c)^2)*(A)^(1/b-1) #dx/dy
    sigma2 = summary(fit)$resVar
    
    }

#    # debug use
#    plotCurv(fit); abline(h=y); abline(2,dx.dy/x)

    s1=dx.dy^2*sigma2/m /x^2
    s2=(D.beta%*%V.beta%*%D.beta) / x^2
    se.t = sqrt(s1 + s2)
    se.x = x*se.t
    return ( c("log.conc"=unname(log(x)), "s.e."=se.t, "concentration"=unname(x), "lower.bound"=exp(log(x)-2*se.t), "upper.bound"=exp(log(x)+2*se.t), "s1"=unname(s1), "s2"=unname(s2), "se.x"=unname(se.x) ))
}

# one can create a new function
getDiffSd=function(fit, x1, x2) {
    
}

# x is a vector of observations from first group, y is a vector of observations from second group, x.sd is a vector of sd for x
# return AUC without adjustment, and adjusting for error 
AUC.e=function (x,y, x.sd){
    x.sd=x.sd[!is.na(x)]    
    x=x[!is.na(x)]    
    y=y[!is.na(y)]    
    c(mean(outer(x,y,"<")),
      mean(outer (1:length(x), y, function (i,y1){
        pnorm(q=y1, mean=x[i], sd=x.sd[i], lower.tail=T)
      }))
    )
}

# fit a concave (default) or convex, montoically increasing nonparametric least square fit
# x and y are both vectors
convexcave.incr.ls = function (x,y, concave=T, convex=F) {
    
    n=length(x)
    A=matrix(0,n,2*n)
    for (i in 1:n) {
        A[i,2*i-1]=1
        A[i,2*i]=x[i]
    }
    
    G=matrix(0,n*n, 2*n)
    for (i in 1:n) {
        G[i,2*i]=1
    }
    for (i in 1:n) {
        cursor=0
        for (j in setdiff(1:n, i)) {
            cursor=cursor+1
            G[n+(i-1)*(n-1)+cursor,2*i-1]=-1
            G[n+(i-1)*(n-1)+cursor,2*i]  =-x[i]
            G[n+(i-1)*(n-1)+cursor,2*j-1]=1
            G[n+(i-1)*(n-1)+cursor,2*j]  =x[i]
        }
    }
    if (!concave | convex) G[(n+1):(n*n),]=-G[(n+1):(n*n),]
    
    require (limSolve)
    cf=lsei ( A=A, B=y, E=NULL, F=NULL, G=G, H=rep(0,n*n))$X
    y.fit = A %*% cf
    
#    require(quadprog)
#    #solve.QP(Dmat,dvec,Amat,bvec=bvec)
#    # Dmat not full rank
    
#    require(kernlab)
#    H <- Dmat
#    c <- -dvec
#    A <- t(Amat)
#    b <- bvec
#    l <- matrix(rep(0,2*n))
#    u <- matrix(rep(1e4,2*n))
#    r <- matrix(rep(1e4,n*n))
#    sv <- ipop(c,H,A,b,l,u,r)
#    # Error: system is computationally singular
    
}

sigmoid.incr.ls = function (x,y,k) {
    
    require (limSolve)
    
    n=length(x)
    A=matrix(0,n,2*n)
    for (i in 1:n) {
        A[i,2*i-1]=1
        A[i,2*i]=x[i]
    }
    
    # beta are positive
    G.1=matrix(0,n, 2*n)
    for (i in 1:n) {
        G.1[i,2*i]=1
    }
    
    # convex part
    G.2=matrix(0,(k+1)*k,2*n)
    for (i in 1:(k+1)) {
        cursor=0
        for (j in setdiff(1:(k+1), i)) {
            cursor=cursor+1
            G.2[(i-1)*k+cursor,2*i-1]=-1
            G.2[(i-1)*k+cursor,2*i]  =-x[i]
            G.2[(i-1)*k+cursor,2*j-1]=1
            G.2[(i-1)*k+cursor,2*j]  =x[i]
        }
    }
    G.2=-G.2 # convexify
    
    # concave part
    G.3=matrix(0,(n-k+1)*(n-k),2*n)
    for (i in k:n) {
        cursor=0
        for (j in setdiff(k:n, i)) {
            cursor=cursor+1
            G.3[(i-k)*(n-k)+cursor,2*i-1]=-1
            G.3[(i-k)*(n-k)+cursor,2*i]  =-x[i]
            G.3[(i-k)*(n-k)+cursor,2*j-1]=1
            G.3[(i-k)*(n-k)+cursor,2*j]  =x[i]
        }
    }
    
    # equality by inequality
    G.4=matrix(0,4,2*n)
    G.4[1,2*k-1]= 1; G.4[1,2*k+1]=-1
    G.4[2,2*k-1]=-1; G.4[2,2*k+1]= 1
    G.4[3,2*k  ]= 1; G.4[3,2*k+2]=-1
    G.4[4,2*k  ]=-1; G.4[4,2*k+2]= 1
    G=rbind(G.1, G.2, G.3, G.4)
    cf=try(lsei (type=2, A=A, B=y, E=NULL, F=NULL, G=G, H=rep(0,nrow(G)))$X)
    if (!inherits(cf, "try-error")) {
        y.fit.1 = A %*% cf
    } else {
        y.fit.1 = rep(mean(y), n)    
    }
        
    # equality by equality
    E=matrix(0,2,2*n)
    E[1,2*k-1]= 1; E[1,2*k+1]=-1
    E[2,2*k  ]= 1; E[2,2*k+2]=-1
    G=rbind(G.1, G.2, G.3)
    cf=try(lsei (A=A, B=y, E=E, F=rep(0,nrow(E)), G=G, H=rep(0,nrow(G)))$X)
    if (!inherits(cf, "try-error")) {
        y.fit.2 = A %*% cf
    } else {
        y.fit.2 = rep(mean(y), n)    
    }
    
    if(sum((y-y.fit.1)**2) < sum((y-y.fit.2)**2))
        return (y.fit.1)
    else 
        return (y.fit.2)
    
#    # checking constraints
#    all(G%*%cf+1e-10>0) # add 1e-10 for R rounding errors
#    cf.1=cf
#    cf.1[3:4]=cf.1[1:2]
#    cf.1[5:6]=coef(lm(y[3:4]~x[3:4]))
#    cf.1[5:6]=cf.1[7:8]
#    for (ii in c(9,11,13,15,17) )     cf.1[ii:(ii+1)]=cf.1[7:8]
#    all(G%*%cf.1+1e-10>0) # add 1e-10 for R rounding errors
    
}

# better ssfct to get better fits
# Use gof.threshold to report lack of fit
# this is only working for log transformed
# this is not working for weighting for two reasons 1) if weights are present, fails 2) gof needs to be computed differently
# robust="mean"; fit.4pl=FALSE; force.fit=F; weighting=F # default
fit.drc=function (formula, data, robust="mean", fit.4pl=FALSE, force.fit=F, weighting=F) {
    
    gof.threshold=.2 # .2 is empirically determined
    control=drmc(maxIt=5000, method="BFGS", relTol=1e-7, trace=F)
    
    gofs=rep(Inf, 3)
    fits=list()
    
    if (!fit.4pl){
        # I had to write one line for weighting and one for no weighting, I cannot find a way around it. because weights is evaluated in the global env
        if (weighting) {
            fit1= try(drm(formula=formula, data=data, robust=robust, fct = LL.5(ssfct=ss.fct.via.LL4), control=control, weights=fi.avg^drm.weights.var.power), silent=T)    
        } else {
            fit1= try(drm(formula=formula, data=data, robust=robust, fct = LL.5(ssfct=ss.fct.via.LL4), control=control), silent=T)    
        }
        
        if (!inherits(fit1, "try-error")) {
            vcov.=vcov(fit1)
            if(is.null(vcov.)) bad.se = T else {
                if (any(diag(vcov.)<0)) bad.se=T else bad.se=F
            }
            if (bad.se) gof1=Inf
            else gof1 = gof.cost( resid(fit1) ) 
        } else {
            gof1=Inf
        }
        gofs[1]=gof1
        fits[[1]]=fit1
        
        if (gof1>gof.threshold) {
            
            print("ss.fct.via.LL4 fails, try ssfct.drc.1.5.2")
            if (weighting) {
                fit2= try(drm(formula=formula, data=data, robust=robust, fct = LL.5(ssfct=ssfct.drc.1.5.2), control=control, weights=fi.avg^drm.weights.var.power), silent=T)
            } else {
                fit2= try(drm(formula=formula, data=data, robust=robust, fct = LL.5(ssfct=ssfct.drc.1.5.2), control=control), silent=T)
            }
            
            if (!inherits(fit2, "try-error")) {
                vcov.=vcov(fit2)
                if(is.null(vcov.)) bad.se = T else {
                    if (any(diag(vcov.)<0)) bad.se=T else bad.se=F
                }
                if (bad.se) gof2=Inf
                else gof2 = gof.cost( resid(fit2) ) 
            } else gof2=Inf
            gofs[2]=gof2
            fits[[2]]=fit2
            
            if (gof2>gof.threshold) {
                
                print("ssfct.drc.1.5.2 fails, try default ssfct")
                if (weighting){
                    fit3 = try(drm(formula=formula, data=data, robust=robust, fct = LL.5(), control=control, weights=fi.avg^drm.weights.var.power), silent=T)
                } else {
                    fit3 = try(drm(formula=formula, data=data, robust=robust, fct = LL.5(), control=control), silent=T)
                }
                
                if (!inherits(fit3, "try-error")) {
                    vcov.=vcov(fit3)
                    if(is.null(vcov.)) bad.se = T else {
                        if (any(diag(vcov.)<0)) bad.se=T else bad.se=F
                    }
                    if (bad.se) gof3=Inf
                    else gof3 = gof.cost( resid(fit3) ) 
                } else gof3=Inf
                gofs[3]=gof3
                fits[[3]]=fit3
                if (gof3>gof.threshold) print ("fits failed")
                else print("worked")
                
            } else print("worked")
        
        } 
        
        fit=fits[[which.min(gofs)]]
        
    } else {
        if (weighting) {
            fit= try(drm(formula=formula, data=data, robust=robust, fct = LL.4(), control=control, weights=fi.avg^drm.weights.var.power), silent=T)  
        } else {
            fit= try(drm(formula=formula, data=data, robust=robust, fct = LL.4(), control=control), silent=T)  
        }
        if (!inherits(fit, "try-error")) {
            vcov.=vcov(fit)
            if(is.null(vcov.)) bad.se = T else {
                if (any(diag(vcov.)<0)) bad.se=T else bad.se=F
            }
            if (bad.se) gof3=Inf
            else gof3 = gof.cost( resid(fit) ) 
        } else gof3=Inf
        gofs[1]=gof3
        
    }
    
    if (force.fit) {
        if (class(fit)=="try-error") return (NULL) 
        else {
            print("return forced fit")
            return (fit)
        }
    } else {
        if (min(gofs)>gof.threshold) {
            print("goodness of fit statistics too large, fit failed")
            return (NULL)
        }
        else return (fit)
    }
}
#fit.drc(fi ~ expected_conc, data = dat)
#fit.drc(MFI ~ Expected.Conc, data = tt, weights= tt$MFI.avgY^-1)

# note for self: needs to define sample_id before calling rumi if the data is from LDO (internal)
# dat$fi needs to be positive
# default: 
# plot=TRUE; auto.layout=TRUE; plot.se.profile=TRUE; force.fit=FALSE; test.LOD=FALSE; find.LOD=FALSE; find.best.dilution=FALSE; return.fits=FALSE; grid.len=NULL; unk.replicate=NULL; verbose=FALSE; type="f"; robust="mean"
rumi = function (dat,
    plot=TRUE, auto.layout=TRUE, plot.se.profile=TRUE,
    force.fit=FALSE, test.LOD=FALSE,
    find.LOD=FALSE, find.best.dilution=FALSE, return.fits=FALSE,
    grid.len=NULL, unk.replicate=NULL, verbose=FALSE, type="f", fit.4pl=FALSE, robust="mean", log.transform=T, weighting=F, 
    ...)
{
    if (type=="n") {
        # just construct a rumi object with the data
        out=list()
        attr(out, "class")="rumi"
        out$data=dat
        return (out)
    }
    
    if (!log.transform) {
        weighting=T
    }
    
    if (weighting) {
        if (!exists("drm.weights.var.power")) stop("drm.weights.var.power has to be defined as a global variable for weighting to work")
    }
    
    # convert bead_type to analyte
    if (is.null(dat$analyte) & !is.null(dat$bead_type)) dat$analyte=dat$bead_type
    
    # checking the data
    if (is.null(dat$sample_id)) {cat("ERROR: sample_id missing from dat\n\n"); stop()}
    if (is.null(dat$assay_id)) {cat("ERROR: assay_id missing from dat\n\n"); stop()}
    if (is.null(dat$analyte)) {cat("ERROR: analyte missing from dat\n\n"); stop()}
    if (is.null(dat$well_role)) {cat("ERROR: well_role missing from dat\n\n"); stop()}
    if (is.null(dat$fi)) {cat("ERROR: fi missing from dat\n\n"); stop()}
    if (is.null(dat$starting_conc) & is.null(dat$expected_conc)) {cat("ERROR: starting_conc and expected_conc missing from dat\n\n"); stop()}
    if (!is.numeric(dat$fi)) {cat("ERROR: dat$fi not numeric\n\n"); stop()}
    
    # set grid length for computing error profile
    if (is.null(grid.len) & plot.se.profile) grid.len=250
    if (is.null(grid.len) & find.LOD) grid.len=1000
    
    if (!plot) plot.se.profile=F
    
    # filter out rows with fi being NA
    dat=subset(dat, !is.na(fi))
    
    ana=sort(unique(dat$analyte))
    #ana=sort(setdiff(unique(dat$analyte), "blank"))
    assays=sort(setdiff(unique(dat$assay_id), "blank"))
    high.low=NULL
    LOQ=NULL
    out=data.frame()
    fits=list()
    for (p in assays) {
    
        if (verbose) myprint (p)
    
        for (a in ana) {
    
            if (auto.layout) {
                if (plot.se.profile) par(mfrow=c(2,2)) else par(mfrow=c(1,1))
            }
    
            if (verbose) myprint(a)
            dat.a.p=subset(dat, assay_id==p & analyte==a)
            if (nrow(dat.a.p)==0) next
    
            dat.std=subset(dat.a.p, well_role=="Standard" )
            if (is.null(dat.std$expected_conc)) dat.std$expected_conc=dat.std$starting_conc/dat.std$dilution
            if (nrow(dat.std)==0) next
            if (any(is.na(dat.std$expected_conc))) {
                stop("some expected_conc are NA")
            }
            std.low =log(min (dat.std$expected_conc))
            std.high=log(max (dat.std$expected_conc))
            
            stand.avg=aggregate(dat.std$fi, by = list(dat.std$analyte, dat.std$expected_conc, dat.std$assay_id), mean)
            names(stand.avg) = c("analyte", "expected_conc","assay_id", "fi.avg")
            dat.std = merge(dat.std, stand.avg, by=c("analyte", "expected_conc","assay_id"), all.x=T, all.y=T)
            
            if (log.transform) formula.=log(fi) ~ expected_conc else formula.=fi ~ expected_conc 
            fit= fit.drc(formula., data = dat.std, robust=robust, weighting=weighting, force.fit=force.fit, fit.4pl=fit.4pl)
            if (return.fits) fits[[p%+%a]]=fit
    
            if (is.null(fit)) {
    
                if (plot) {
                    plot (fi ~ expected_conc, data = dat.std, log="xy", main="FAILED: "%+%p%+%", "%+%a, cex=.1)
                    if (plot.se.profile) empty.plot()
                }
                bad.se=T # needed after this if statement
    
            } else {
    
                if (plot) {
                    # this pch is not used by plot.drc, nonetheless, keep it here for now
                    if (!is.null(dat.std$replicate)) pch=ifelse(dat.std$replicate==1, 1, 19) else pch=1
                    plot(fit, type="all", main=p%+%", "%+%a, cex=.5, xlim=c(min(fit$data[,1]), max(fit$data[,1])),pch=pch,log=ifelse(log.transform,"x","xy"),...)
                }
    
                # sometimes, even though fit is not NULL, some standard errors of the parameter estimates are negative
                vcov.=vcov(fit)
                if(is.null(vcov.)) bad.se = T else {
                    if (any(diag(vcov.)<0)) bad.se=T else bad.se=F
                }
                if (verbose & bad.se) print("bad.se")
                if (bad.se & plot.se.profile) empty.plot()
    
                # estimate unknown concentrations
                dat.unk=subset(dat.a.p, well_role!="Standard")
                sam = unique(dat.unk$sample_id)
                if (!is.null(sam)) sam=sort(sam)
                for (s in sam) {
                    if (verbose) myprint(s)
                    dil=sort(unlist(unique(subset(dat.unk, sample_id==s, select=dilution))))
                    out.s=data.frame()
                    for (d in dil) {
                        if (verbose) myprint(d)
                        # for each sample/dilution, there may be replicates
                        dat.unk.s.d = subset(dat.unk, dilution == d & sample_id == s)
                        if (is.null(unk.replicate)) unk.replicate=nrow(dat.unk.s.d)
                        if (log.transform) aux=log(dat.unk.s.d$fi) else aux=dat.unk.s.d$fi
                        estimated = unname(getConc(fit, aux, fit.4pl = fit.4pl)) ###CHANGE 4 6/16/2011
    
                        if (!bad.se) {
    
                            # test limits of detection
                            if (test.LOD) {
                                test.1.not.rejected=(estimated[1] - std.low)/estimated[2] < 1.64 | estimated[2]==Inf
                                test.2.not.rejected=(std.high - estimated[1])/estimated[2] < 1.64 | estimated[2]==Inf
                                if(test.1.not.rejected & !test.2.not.rejected) estimated[1] = std.low
                                if(test.2.not.rejected & !test.1.not.rejected) estimated[1] = std.high
                                # if both rejected, set to the closer one
                                if(test.1.not.rejected & test.2.not.rejected) estimated[1] = ifelse (estimated[1] > log((exp(std.low)+exp(std.high))/2), std.high, std.low)
                                # set std err to Inf for those touched
                                if(test.1.not.rejected | test.2.not.rejected) estimated[2] = Inf
                            }
    
                            out.s=rbind (out.s, data.frame (c(dat.unk.s.d[1,], "est.log.conc"=estimated[1]+log(d), "se"=estimated[2], 
                                "est.conc"=exp(estimated[1]+log(d)), "lb.conc"=exp(estimated[1]+log(d)-2*estimated[2]), "ub.conc"=exp(estimated[1]+log(d)+2*estimated[2])  )))
                        } else {
                            out.s=rbind (out.s, data.frame (c(dat.unk.s.d[1,], "est.log.conc"=estimated[1]+log(d), "se"=NA, 
                                "est.conc"=exp(estimated[1]+log(d)), "lb.conc"=NA, "ub.conc"=NA  )))
                        }
                    }
                    if (!find.best.dilution) {
                        if(length(dil)>1) warning ("There are most than one dilutions for this sample, and we are returning all. sample_id: "%+%s)
                        out=rbind(out, out.s)
                    } else {
                        out=rbind(out, out.s[which.min(out.s$se), ])
                    }
                }
    
                # if there is no sample, unk.replicate may still be null
                if (is.null(unk.replicate)) unk.replicate=1
                    
                # plot se profile file and others
                if (!bad.se & (find.LOD | plot.se.profile)) {
                    # compute x.high and x.low
                    fit.low=predict(fit, data.frame(expected_conc=min(fit$data[,1])))
                    fit.high=predict(fit, data.frame(expected_conc=max(fit$data[,1])))
                    if (fit.low>fit.high) next
                    mid.log.fi = unname((fit.low+fit.high)/2)
                    d.95=1.96
                    d.99=2.575829
                    # low end
                    x.hat.low=mysapply(seq(fit.low, mid.log.fi, length=grid.len+1)[-1], function (x) getConc(fit, rep(x,unk.replicate), fit.4pl = fit.4pl)[c(1,2,6,7,8,4,5)]) ###CHANGE 5 6/16/2011
                    same.as.low=x.hat.low[,1]-d.95*x.hat.low[,2]<log(min(dat.std$expected_conc))
                    same.as.low.rle=rle(same.as.low)
                    tmp=nrow(x.hat.low)-last(same.as.low.rle$lengths)
                    x.low=x.hat.low[ifelse(tmp>0,tmp,1), 1]
                    # high end
                    x.hat.high=mysapply(seq(fit.high, mid.log.fi, length=grid.len+1)[-1], function (x) getConc(fit, rep(x,unk.replicate), fit.4pl = fit.4pl)[c(1,2,6,7,8,4,5)]) ###CHANGE 6 6/16/2011
                    same.as.high=x.hat.high[,1]+d.95*x.hat.high[,2]>log(max(dat.std$expected_conc))
                    same.as.high.rle=rle(same.as.high)
                    tmp=nrow(x.hat.high)-last(same.as.high.rle$lengths)
                    x.high=x.hat.high[ifelse(tmp>0,tmp,1), 1]
                    high.low=rbind(high.low,c(p,a,x.high,x.low))
                    # plot vertical lines at x.high and x.low
                    if (find.LOD) {
                        abline(v=exp(x.low))
                        abline(v=exp(x.high))
                    }
                    # plot error profile
                    if (plot.se.profile) {
                        tmp=rbind(x.hat.low, x.hat.high[nrow(x.hat.high):1,])
                        tmp=tmp[tmp[,2]!=Inf & !is.na(tmp[,2]),]
    
                        plot(tmp[,1], tmp[,2],type="n", xlab="Estimated log conc", ylab="S.E. ("%+%unk.replicate%+%" replicates)", log="", ylim=c(0,max(tmp[,2])), xlim=log(c(min(fit$data[,1]), max(fit$data[,1]))))
                        lines(tmp[,1], sqrt(tmp[,4]),type="l", col="blue")
                        lines(tmp[,1], sqrt(tmp[,3]),type="l", col="red")
                        lines(tmp[,1], tmp[,2],type="l", col="black")
                        legend(legend=c("total","replication sensitive","replication insensitive"),col=c("black","red","blue"),lty=1,x="topright",bty="n", cex=.5)
    
#                        # define se profile as se/estimated conc on linear scale
#                        se.profile=tmp[,5]/exp(tmp[,1])*100
#                        plot(exp(tmp[,1]), se.profile,type="l", xlab="Estimated conc", ylab="% CV ("%+%unk.replicate%+%" replicates)", log="x", ylim=c(0,100), xlim=c(min(fit$data[,1]), max(fit$data[,1])))
#                        abline(h=20)
                        # define se profile as percent cv vs estimated conc, using length of CI, similar to last
                        se.profile=(tmp[,7]-tmp[,6])/4/exp(tmp[,1])*100
                        plot(exp(tmp[,1]), se.profile,type="l", xlab="Estimated log conc", ylab="% CV ("%+%unk.replicate%+%" replicates)", log="x", ylim=c(0,100))
                        abline(h=20)
#                        # define se profile as se/estimated conc on log scale
#                        se.profile=tmp[,2]/tmp[,1]*100
#                        plot(exp(tmp[,1]), abs(se.profile),type="l", xlab="Estimated conc", ylab="% CV ("%+%unk.replicate%+%" replicates)", log="x", ylim=c(0,100))
#                        abline(h=20)
                        # LOQ is defined on linear scale
                        rle1 = rle(abs(unname(se.profile))<20)
                        if (sum(rle1[[2]])==1) {
                            loq.ind=which(rle1[[2]])
                            LOQ=rbind(LOQ, c(p,a,exp(tmp[c(ifelse(loq.ind==1, 1, 1+cumsum(rle1[[1]])[loq.ind-1]), cumsum (rle1[[1]])[loq.ind]),1])))
                        } else if (sum(rle1[[2]])==0) {
                            LOQ=rbind(LOQ, c(p,a,NA,NA))
                        } else {
                            stop("rle1 not quite right, "%+%p%+%a)
                        }
                    }
                }
            }
        }
    }
    if (find.LOD & !is.null(fit)) {
        LOD=as.data.frame(high.low, stringsAsFactors=FALSE) # without stringsAsFactors=FALSE, sometimes x.high/x.low are set to factor
        names(LOD)=c("assay","analyte","x.high","x.low")
        LOD$x.high=exp(as.double(LOD$x.high))
        LOD$x.low=exp(as.double(LOD$x.low))
        attr(out, "LOD")=LOD
    }
    if (plot.se.profile & !is.null(fit) & !bad.se) {
        LOQ=as.data.frame(LOQ, stringsAsFactors=FALSE) # without stringsAsFactors=FALSE, sometimes x.high/x.low are set to factor
        names(LOQ)=c("assay","analyte","lloq","rloq")
        LOQ$lloq=as.double(LOQ$lloq)
        LOQ$rloq=as.double(LOQ$rloq)
        attr(out, "LOQ")=LOQ
    }
    if (return.fits) attr(out, "fits")=fits
    return (out)
}

# fit is returned by fit.jags?; to plot drc fit, use plot.drc()
# if assay_id is not null, then only one curve is plotted, e.g. "LMX004-L-RV144"
# when fit2 is not null, then the second fit is used to plot another line
# only Standard are used
# only works with two replicates for now
# default parameters
# assay_id=NULL; add=F; lcol=1; main=NULL; fit2=NULL; lwd=1; points.only=FALSE; all.lines.only=FALSE; t=NULL; pcex=1; ylim=NULL
plot.rumi=function(fit, assay_id=NULL, add=F, lcol=1, main=NULL, fit2=NULL, lwd=1, points.only=FALSE, all.lines.only=FALSE, t=NULL, pcex=1, ylim=NULL, same.ylim=FALSE, lty3=NULL,fit3=NULL,lcol2=NULL,lcol3=NULL,xlab=NULL,col.outliers=TRUE,lty=1){
    
    dat=fit$data
    dat=subset(dat, well_role=="Standard")
    if (!is.null(assay_id)) assay_names=assay_id else assay_names=unique(dat$assay_id)
    
    # add mixture.indicators to the data frame
    if (!is.null(fit$mixture.indicators) ) {
        if (!any(is.na(fit$mixture.indicators))) {
            dat$mixture.indicators=fit$mixture.indicators
        }
    } 
    
    if (all.lines.only) {
        t=log(dat$expected_conc)[dat$assay_id==assay_names[1]]
        y=log(dat$fi)[dat$assay_id==assay_names[1]]
        plot(t,y,main=ifelse(is.null(main),"",main),type="n",ylim=ylim,xlab=xlab)
    }
    
    if (same.ylim) ylim=range(log(dat$fi))
    for(a in assay_names) {
        dat.a=subset(dat, assay_id==a)    
        # order points
        dat.a=dat.a[order(dat.a$expected_conc),]
        
        t=log(dat.a$expected_conc)
        
        # plot points
        if (!add & !all.lines.only) {
            y=log(dat.a$fi)
            col=1
            if(col.outliers)
                if (!is.null(fit$mixture.indicators) ) {
                    if (!any(is.na(fit$mixture.indicators))) {
                        col=ifelse(dat.a$mixture.indicators>.5,2,1)
                    }
                } 
            if (!is.null(dat.a$replicate)) pch=ifelse(dat.a$replicate==1, 1, 19) else pch=1
            plot(t,y,main=ifelse(is.null(main),a,main),col=col, cex=pcex, pch=pch,ylim=ylim,xlab=xlab)
        }
                
        # plot lines
        if (!points.only & !is.null(fit$coefficients)) {
            t.1=seq(min(t), max(t), length=1000)
            lines(t.1, FivePL.t(t.1, fit$coefficients[a,]), lty=lty, col=lcol, lwd=lwd)
            if (!is.null(fit2)) {
                lines(t.1, FivePL.t(t.1, fit2$coefficients[a,]), lty=lty, col=ifelse(is.null(lcol2),2,lcol2), lwd=lwd)
            }
            if (!is.null(fit3)) {
                lines(t.1, FivePL.t(t.1, fit3$coefficients[a,]), lty=ifelse(is.null(lty3),lty,lty3), col=ifelse(is.null(lcol2),3,lcol3), lwd=lwd)
            }
        }
    }
}


# seem to work with jags 2.1 but not 3.2
# default values for the optional parameters
# n.iter=1e5; jags.seed=1; n.thin=1; keep.data=TRUE; keep.jags.samples=FALSE
fit.jags = function (dat, model, informative.prior,
    n.iter=1e5, jags.seed=1, n.thin=1, keep.data=TRUE, keep.jags.samples=FALSE, t.unk.truth=NULL, params.true=NULL, T.init=NULL, prior.sensitivity.ana=NULL, verbose=F)
{
    if (verbose) print(model)
    
    # check data
    if (substr(model,1,2)=="nn") {
        if (is.null(dat$replicate)) stop ("for model nn_xxx, replicate is required columns of data")
        dat=dat[order(dat$replicate),]        
    }
    
    # ordering the data helps later to tell which is which in the indicators
    dat=dat[order(dat$expected_conc),]
    assay_names=unique(dat$assay_id)
    dat=dat[order(dat$assay_id),]
    dat=rbind(subset(dat, well_role=="Standard"), subset(dat, well_role=="Unknown"))
    
    n.replicate=max(dat$replicate)
    
    # create seqno column, assuming all curves have the same dilution!
    dat$seqno=as.numeric(as.factor(dat$expected_conc))
    nDil=max(dat$seqno,na.rm=TRUE)
    
    # create i.curve column to index curves, used by the model file
    dat$i.curve=as.numeric(as.factor(dat$assay_id))
    n.curve=max(dat$i.curve)
    
    # make sure sample_id is NA for Standard and is 1:S for Unknown
    dat$sample_id[dat$well_role=="Standard"]=NA
    dat$sample_id[!is.na(dat$sample_id)]=as.numeric(as.factor(dat$sample_id[!is.na(dat$sample_id)]))
            
    # do drm fits, fitted parameter will be used to get initial values for samplers
    fits = attr(rumi(dat, return.fits=T, force.fit=T, plot.se.profile=F, auto.layout=F, plot=F), "fits")
    params.drm = mysapply(fits, mycoef)
    if (model %in% c("nn_gh_lar1","nn_gh_tar1","nn_gh_mixnorm","nn_gh_norm","nn_gh_replicate_re")) {
        theta.init=cla2gh(params.drm)
        theta.init[,4]=log(theta.init[,4])
        theta.init[,5]=log(theta.init[,5])
        var.matrix=var.matrix.gh
        R=R.gh
        mean.distr=mean.distr.gh
    } else if(model %in% c("nn_classical_mixnorm", "nn_classical_lar1", "nn_classical_tar1", "nn_classical_norm", "nn_classical_replicate_re")) {
        theta.init=cbind(params.drm[,"c"], params.drm[,"d"], log(params.drm[,"e"]), log(-params.drm[,"b"]), log(params.drm[,"f"]))
        var.matrix=var.matrix.classical
        R=R.classical
        mean.distr=mean.distr.classical
    } 
    sd.resid=(sqrt(sapply(fits, function (fit) summary(fit)$resVar)))
    if (verbose) print(theta.init)
    
    if (!is.null(prior.sensitivity.ana)) {
        if (prior.sensitivity.ana==1){
            scale.f=2
            R["g","g"]=R["g","g"]*scale.f**2
            R["logh","logh"]=R["logh","logh"]*scale.f**2
        } else if (prior.sensitivity.ana==2){
            scale.f=4
            R["g","g"]=R["g","g"]*scale.f**2
            R["logh","logh"]=R["logh","logh"]*scale.f**2
        } else if (prior.sensitivity.ana==3){
            scale.f=2
            R["c","c"]=R["c","c"]*scale.f**2
            R["d","d"]=R["d","d"]*scale.f**2
            R["logf","logf"]=R["logf","logf"]*scale.f**2
        } else if (prior.sensitivity.ana==4){
            scale.f=4
            R["c","c"]=R["c","c"]*scale.f**2
            R["d","d"]=R["d","d"]*scale.f**2
            R["logf","logf"]=R["logf","logf"]*scale.f**2
        } else {
            stop("prior.sensitivity.ana not supported: "%+%prior.sensitivity.ana)
        }
    }
    
    if (model %in% c("n","t4","nn")) {
        model.file="modelSame.txt"
    } else if (model == "nn_gh_lar1") {
        model.file="model_gh_lar1.txt"
    } else if (model == "nn_gh_mixnorm") {
        model.file="model_gh_mixnorm.txt"
    } else if (model == "nn_gh_norm") {
        model.file="model_gh_norm.txt"
    } else if (model == "nn_classical_lar1") {
        model.file="model_classical_lar1.txt"
    } else if (model == "nn_classical_tar1") {
        model.file="model_classical_tar1.txt"
    } else if (model == "nn_gh_tar1") {
        model.file="model_gh_tar1.txt"
    } else if (model == "nn_classical_mixnorm") {
        model.file="model_classical_mixnorm.txt"
    } else if (model == "nn_classical_replicate_re") {
        model.file="model_classical_replicate_re.txt"
    } else if (model == "nn_gh_replicate_re") {
        model.file="model_gh_replicate_re.txt"
    } else if (model == "nn_classical_norm") {
        model.file="model_classical_norm.txt"
    } else stop("model not supported")
    
    # model parameters
    if (model %in% c("nn_gh_lar1","nn_gh_mixnorm","nn_gh_norm","nn_classical_lar1","nn_classical_tar1","nn_classical_replicate_re","nn_gh_replicate_re","nn_gh_tar1","nn_classical_mixnorm","nn_classical_norm")) {
        var.comp = c(2, 0.02)
        var.comp.2 = c(2, 0.2) # second component 
        dof=c(Inf,Inf)
    } else if (model=="t4") {
        mixp=0
        dof=c(4,Inf)
        var.comp=c(2,0.002) # a flat prior on tau, also favors large tao, small variance
        var.comp.2=var.comp # doesn't matter
    } else if (model=="nn") {
        mixp=0.05
        var.comp=c(2,0.02) # empirical Bayes estimate
        var.comp.2=c(2,0.2) # the second component is expected to have a much smaller preicsion and larger variance
        dof=c(Inf,Inf)
    } else if (model=="n") {
        mixp=0
        dof=c(Inf,Inf)
        var.comp=c(2,0.02) # empirical Bayes estimate
        var.comp.2=var.comp # doesn't matter
    } else stop ("model not supported")
    
    require(rjags)
#    wd=3 # weak
#    wd=10 # strong
    if(!informative.prior) {
        dof.wish=5; R=diag(1,5)
        v=rep(0,5); m=diag(1e-4, 5)
    } else {
        dof.wish=8; R=R
        v=mean.distr[1,]; m=diag(mean.distr[2,])
    }
    jags.data = list("t"=log(dat$expected_conc), "y"=log(dat$fi), "i.curve"=dat$i.curve, "I"=n.curve, "K"=sum(dat$well_role=="Standard"), "nDil"=nDil, "seqno"=dat$seqno, "dof"=dof, "var.comp"=var.comp,
        "dof.wish"=dof.wish, "R"= R,         
        "v"=v, "m"=m, 
#        dof.wish.1=wd + 4, "R1"= diag(diag(var.matrix))*(wd-2), 
        "precision.matrix"=diag(1/diag(var.matrix)),
        "var.comp.2"=var.comp.2,
        "J"=sum(dat$well_role=="Unknown"), "sample_id"=dat$sample_id, "S"=length(setdiff(unique(dat$sample_id),NA)),
        "t.min"=min(log(dat$expected_conc), na.rm=TRUE), "t.max"=max(log(dat$expected_conc), na.rm=TRUE)
    )
    if (substr(model,1,2)=="nn") {
        jags.data=c(jags.data, list("replicate"=dat$replicate))
    }
    if (model=="nn_classical_replicate_re" | model=="nn_gh_replicate_re")    jags.data=c(jags.data, list("dof.wish.0"=5, "R0"= diag(1,5)))
    
    if(is.null(T.init)) T.init=array(0,dim=c(n.curve,n.replicate,nDil)) # T is now a 3-dimensional vector
    jags.inits = list( 
        # if comment out next line, we will have random starting values for T
        "T"=T.init, 
        "tau1"=100, 
        "r"=8,
        #"t.unk.sample"=mean(min(log(dat$expected_conc), na.rm=TRUE)),
        "theta"=theta.init, "theta.0"=colMeans(theta.init), "TAO"=diag(1/diag(var.matrix)), "mixp"=.05, alpha=0.5,
        .RNG.name="base::Mersenne-Twister", .RNG.seed=jags.seed +11
    ) 
    if (model=="nn_classical_replicate_re" | model=="nn_gh_replicate_re"){
        theta.r.init=array(0,dim=c(n.curve,2,5))
        jags.inits=c(jags.inits, list("theta.r"=theta.r.init, "W"=diag(10/diag(var.matrix)) ))
    }   
    #if (verbose) print(jags.inits)
    
    pname=c("c","d","f","g","h") # these have to be alphabetically ordered, so as to match the order of columns in jags samples
    if (endsWith(model,"replicate_re")) {
        trace.var="p"%+% pname
    } else trace.var=pname
    if (substr(model,1,2)=="nn") {
        if(!contain(model,"tar1")){
            trace.var =c(trace.var,"sigma","T","mixp","alpha")
        } else {
            trace.var =c(trace.var,"sigma","alpha")
        }
        
    } else {
        trace.var =c(trace.var,"sigma","T","mixp")        
    }
    if (length(setdiff(unique(dat$sample_id),NA))>0) trace.var=c(trace.var, "t.unk.sample", "T.unk")
    
    if (verbose) print("fit jags.model ...")
    n.burnin=n.iter/n.thin/2 # 50% burnin
    jags.model.1 = try(jags.model(file= system.file(package="Ruminex")[1] %+% "/jags_script/" %+% model.file, data=jags.data, inits=jags.inits, n.chain = 1, n.adapt=1e3) , silent=F)
    if (inherits(jags.model.1, "try-error")) {
        print("jags.model fails");
        return (NULL)
    } 
    samples = coda.samples(jags.model.1, trace.var, n.iter=n.iter, thin = n.thin )[[1]][-(1:n.burnin),,drop=FALSE]
    
    fit=list()
    attr(fit, "class")="rumi"         
    if (keep.jags.samples) fit$jags.samples=samples
    
    if("alpha" %in% colnames(samples)) fit$alpha=mean(samples[,"alpha"])
    
    # summarize posterior distributions for parameters: median, sd, 95% CI
    if (!endsWith(model,"replicate_re")) {
        samples.2=samples[, regexpr("^[cdghf]\\[.+\\]", colnames(samples))!=-1, drop=F ] # select columns
        if (ncol(samples.2)==0) samples.2=samples[, regexpr("^[cdghf]", colnames(samples))!=-1,drop=F ] # if there is only one curve, the column names are b,c,d,e,f
    } else {
        samples.2=samples[, regexpr("^p[cdghf]\\[.+\\]", colnames(samples))!=-1, drop=F ] # select columns
        if (ncol(samples.2)==0) samples.2=samples[, regexpr("^p[cdghf]", colnames(samples))!=-1,drop=F ] # if there is only one curve, the column names are b,c,d,e,f
        colnames(samples.2)=substr(colnames(samples.2),2,1000)
    }
#    print(str(samples.2))
#    print(pname)
    fit$median.coef =matrix(apply(samples.2, 2, median),                        nrow=n.curve, dimnames=list(assay_names, pname)) # median is better than mean here for abc
    fit$mean.coef=matrix(apply(samples.2, 2, mean),                        nrow=n.curve, dimnames=list(assay_names, pname)) 
    fit$mode.coef=matrix(apply(samples.2, 2, function(x) {den<-density(x); den$x[which(den$y==max(den$y))]}),                        nrow=n.curve, dimnames=list(assay_names, pname)) 
    fit$sd.coef=     matrix(apply(samples.2, 2, sd),                            nrow=n.curve, dimnames=list(assay_names, pname))
    fit$low.coef=    matrix(apply(samples.2, 2, function(x) quantile(x,0.025)), nrow=n.curve, dimnames=list(assay_names, pname))
    fit$high.coef=   matrix(apply(samples.2, 2, function(x) quantile(x,0.975)), nrow=n.curve, dimnames=list(assay_names, pname))
    fit$coefficients=fit$median.coef
    fit$coef.samples=samples.2
    
#    if (!is.null(params.true)) {
#        for (k in 1:n.curve) {
#            f0=FivePL.t.func(params.true[k,])
#            apply(samples.2, 1, function(x) {
#                f1=FivePL.t.func( x )
#                integrate( function(t) abs(f1(t)-f0(t)) , lower=min(log.conc), upper=max(log.conc), subdivisions=1000 )$value
#            })
#        }
#        
#    }
#    fit$abc=
    
    fit$fitted = sapply(1:nrow(subset(dat, well_role=="Standard")), function(i.row) {
        FivePL.x(dat$expected_conc[i.row], fit$coefficients[dat[i.row,"assay_id"],])
    })
    fit$resid=log(dat$fi[dat$well_role=="Standard"])-fit$fitted
    
    # summarize posterior distributions for the variance components, there may be one or two
    samples.4=samples[,startsWith(colnames(samples),"sigma"),drop=FALSE ] 
    fit$varcomp=apply(samples.4, 2, function(x) median(x))
    
    if(!contain(model,"tar1")){
        fit$mixp=mean(samples[,"mixp"])
    
        # summarize mixture indicators
        samples.3=samples[,startsWith(colnames(samples),"T[") ] # select columns
        tmp=apply(samples.3, 2, mean) # cannot do median here, because it is Bernoulli variable
        #the following line makes the assumption that there are the same number of points each curve, this is not true sometimes
        #fit$mixture.indicators=matrix(tmp[1:sum(dat$well_role=="Standard")], ncol=n.curve, dimnames=list(1:(sum(dat$well_role=="Standard")/n.curve), assay_names))        
        # simple give it to a vector, should have the same length as the number of rows in fit$data
        if (substr(model,1,2)=="nn") fit$mixture.indicators=tmp["T["%+%dat$i.curve[dat$well_role=="Standard"]%+%","%+%dat$replicate[dat$well_role=="Standard"]%+%","%+%dat$seqno[dat$well_role=="Standard"]%+%"]"]
    }
        
    # summarize Unknown concentrations
    samples.6=samples[,startsWith(colnames(samples),"T.unk[") ] # select columns
    tmp=apply(samples.6, 2, mean) # cannot do median here, because it is Bernoulli variable
    unk = data.frame(subset(dat, well_role=="Unknown"), "mix.ind"=tmp)
    samples.5 = samples[,startsWith(colnames(samples),"t.unk.sample"),drop=FALSE ] 
    if(ncol(samples.5)>0){
        fit$t.unk.mean=  apply(samples.5, 2, function(x) mean(x)) # mean is better than median for unk mse
        fit$t.unk.median=apply(samples.5, 2, function(x) median(x)) 
        fit$t.unk.mode= apply(samples.5, 2, function(x) {den<-density(x); den$x[which(den$y==max(den$y))]} )
        if (!is.null(t.unk.truth)) {    
            fit$t.unk.cp = sapply(1:ncol(samples.5), function(i) {
                x=samples.5[,i]        
                quantile(x,0.025) < t.unk.truth[i] & t.unk.truth[i] < quantile(x,0.975)
            })
            names(fit$t.unk.cp)="sample"%+%1:ncol(samples.5)
            fit$t.unk.mse = sapply(1:ncol(samples.5), function(i) {
                x=samples.5[,i]        
                mean ((x-t.unk.truth[i])**2)
            })
            names(fit$t.unk.mse)="sample"%+%1:ncol(samples.5)
            fit$t.unk.perc.bias = sapply(1:ncol(samples.5), function(i) {
                x=samples.5[,i]        
                mean ((x-t.unk.truth[i])/t.unk.truth[i]*100)
            })
            names(fit$t.unk.mse)="sample"%+%1:ncol(samples.5)
            fit$t.unk.var = sapply(1:ncol(samples.5), function(i) {
                x=samples.5[,i]        
                var (x)
            })
            names(fit$t.unk.mse)="sample"%+%1:ncol(samples.5)
       }
    }
        
    if (keep.data) {
        if(!contain(model,"tar1")){
            fit$data=cbind(dat, fit$fitted, fit$resid, fit$mixture.indicators)
        } else {
            fit$data=cbind(dat, fit$fitted, fit$resid)
        }
    }
    return (fit)        
}
